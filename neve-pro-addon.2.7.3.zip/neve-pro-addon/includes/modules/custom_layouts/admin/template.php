<?php
/**
 * Template for single post of custom layouts.
 *
 * @package Neve_Pro\Modules\Custom_Layouts\Admin
 */
get_header();
do_action( 'neve_custom_layouts_template_content' );
get_footer();
