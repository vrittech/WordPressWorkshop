<?php
/**
 * Layer
 *
 * @package  Neve_Pro\Modules\Access_Restriction\Content_Restriction\Authorization_Layer
 */
namespace Neve_Pro\Modules\Access_Restriction\Content_Restriction\Authorization_Layer;

/**
 * Class Layer
 */
interface Layer {
	/**
	 * Initialization
	 */
	public function init();
}
